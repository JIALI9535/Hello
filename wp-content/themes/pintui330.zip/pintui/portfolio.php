<?php 

/* Template name: Portfolio */


get_header(); 

echo basel_shortcode_portfolio( array() );

get_footer(); ?>