<?php 
	basel_header_block_search_extended( $categories, $ajax, $ajax_args ); 
?>